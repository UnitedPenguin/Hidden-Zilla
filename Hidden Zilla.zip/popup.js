document.addEventListener('DOMContentLoaded', function () {
  const button = document.getElementById('toggleButton');
  button.onclick = function () {
    const isOn = button.textContent === 'Turn On';
    button.textContent = isOn ? 'Turn Off' : 'Turn On';
    browser.runtime.sendMessage({ userAgentSwitch: isOn });
  };
});

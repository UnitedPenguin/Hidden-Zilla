let userAgentSwitch = false;
const CHROME_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537';

browser.runtime.onMessage.addListener((message) => {
  userAgentSwitch = message.userAgentSwitch;
});

browser.webRequest.onBeforeSendHeaders.addListener(
  (details) => {
    if (userAgentSwitch) {
      for (var i = 0; i < details.requestHeaders.length; ++i) {
        if (details.requestHeaders[i].name === 'User-Agent') {
          details.requestHeaders[i].value = CHROME_USER_AGENT;
          break;
        }
      }
    }
    return { requestHeaders: details.requestHeaders };
  },
  { urls: ['<all_urls>'] },
  ['blocking', 'requestHeaders']
);
